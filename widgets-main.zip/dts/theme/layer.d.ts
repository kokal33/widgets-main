export declare enum Layer {
    UNDERLAYER = -1,
    OVERLAY = 100,
    DIALOG = 1000,
    TOOLTIP = 2000
}
