import { Currency } from '@uniswap/sdk-core';
export declare function currencyId(currency: Currency): string;
