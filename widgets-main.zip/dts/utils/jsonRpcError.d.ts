export declare function getReason(error: any): string | undefined;
export declare function isUserRejection(error: any): boolean;
