/// <reference types="react" />
export default function IdenticonIcon(): JSX.Element;
