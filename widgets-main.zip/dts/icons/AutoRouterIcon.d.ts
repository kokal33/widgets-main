/// <reference types="react" />
export default function AutoRouterIcon({ className, id }: {
    className?: string;
    id?: string;
}): JSX.Element;
