import { BigNumber } from '@ethersproject/bignumber';
export default function useCurrentBlockTimestamp(): BigNumber | undefined;
