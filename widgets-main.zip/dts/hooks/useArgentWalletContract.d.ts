import { ArgentWalletContract } from 'abis/types';
export declare function useArgentWalletContract(): ArgentWalletContract | null;
