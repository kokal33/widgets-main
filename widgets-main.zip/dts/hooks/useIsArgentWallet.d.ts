export default function useIsArgentWallet(): boolean;
