export declare function useOutsideClickHandler(node: HTMLDivElement | null, onOutsideClick: () => void): void;
