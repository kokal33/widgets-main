export type { SwapEventHandlers } from 'state/swap';
export default function useSyncSwapRouterUrl(routerUrl?: string): void;
