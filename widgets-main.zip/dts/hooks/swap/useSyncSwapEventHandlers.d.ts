import { SwapEventHandlers } from 'state/swap';
export type { SwapEventHandlers } from 'state/swap';
export default function useSyncSwapEventHandlers(handlers: SwapEventHandlers): void;
