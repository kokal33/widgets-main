import { NativeCurrency, Token } from '@uniswap/sdk-core';
export default function useNativeCurrency(): NativeCurrency | Token;
