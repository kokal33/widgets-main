import { SupportedChainId } from 'constants/chains';
declare function useOnSupportedNetwork(chainId?: SupportedChainId): boolean;
export default useOnSupportedNetwork;
