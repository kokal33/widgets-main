import { WrappedTokenInfo } from 'state/lists/wrappedTokenInfo';
export declare function useQueryTokens(query: string, tokens: WrappedTokenInfo[]): (import("@uniswap/sdk-core").Token | import("@uniswap/sdk-core").NativeCurrency | WrappedTokenInfo)[];
