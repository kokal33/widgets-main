export declare function useIsMobileWidth(): boolean;
