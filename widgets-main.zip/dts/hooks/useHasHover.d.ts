export default function useHasHover(node: Node | null | undefined): boolean;
