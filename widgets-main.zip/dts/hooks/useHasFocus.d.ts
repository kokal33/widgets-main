export default function useHasFocus(node: Node | null | undefined): boolean;
