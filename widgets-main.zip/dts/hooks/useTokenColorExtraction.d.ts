export default function useTokenColorExtraction(): "interactive" | "accent";
