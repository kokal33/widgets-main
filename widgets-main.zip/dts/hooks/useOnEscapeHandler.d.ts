export declare function useOnEscapeHandler(onClose?: () => void): void;
