export declare function useWindowWidth(): number;
