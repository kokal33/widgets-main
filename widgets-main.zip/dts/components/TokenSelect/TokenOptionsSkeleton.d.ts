/// <reference types="react" />
export default function TokenOptionsSkeleton(): JSX.Element;
