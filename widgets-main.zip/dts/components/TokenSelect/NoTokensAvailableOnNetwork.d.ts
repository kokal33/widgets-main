/// <reference types="react" />
export default function NoTokensAvailableOnNetwork(): JSX.Element;
