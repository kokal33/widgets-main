declare const Rule: import("styled-components").StyledComponent<"hr", import("styled-components").DefaultTheme, {
    padded?: true | undefined;
    scrollingEdge?: "bottom" | "top" | undefined;
}, never>;
export default Rule;
