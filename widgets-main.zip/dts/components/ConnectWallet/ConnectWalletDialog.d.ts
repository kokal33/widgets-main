/// <reference types="react" />
export declare function ConnectWalletDialog(): JSX.Element;
