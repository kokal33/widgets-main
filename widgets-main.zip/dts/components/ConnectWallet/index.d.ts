/// <reference types="react" />
interface WalletProps {
    disabled?: boolean;
}
export default function Wallet({ disabled }: WalletProps): JSX.Element | null;
export {};
