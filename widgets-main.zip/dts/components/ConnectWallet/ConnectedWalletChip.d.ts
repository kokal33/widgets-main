/// <reference types="react" />
export default function ConnectedWalletChip({ disabled, account }: {
    disabled?: boolean;
    account?: string;
}): JSX.Element;
