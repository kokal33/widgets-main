/// <reference types="react" />
/** An ActionButton that opens the wallet connection dialog. */
export default function ConnectWalletButton(): JSX.Element;
