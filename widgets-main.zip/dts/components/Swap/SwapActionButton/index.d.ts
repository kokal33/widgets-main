/// <reference types="react" />
export default function SwapActionButton(): JSX.Element;
