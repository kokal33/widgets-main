/// <reference types="react" />
/** A chain-switching ActionButton. */
export default function ChainSwitchButton({ chainId }: {
    chainId: number;
}): JSX.Element;
