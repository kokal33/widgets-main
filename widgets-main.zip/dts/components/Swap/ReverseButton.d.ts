/// <reference types="react" />
export default function ReverseButton(): JSX.Element;
