/// <reference types="react" />
export declare function SettingsMenu(): JSX.Element;
export default function Settings(): JSX.Element;
