/// <reference types="react" />
export default function MaxSlippageSelect(): JSX.Element;
