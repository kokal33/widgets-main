/// <reference types="react" />
export default function TransactionTtlInput(): JSX.Element;
