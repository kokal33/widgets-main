/// <reference types="react" />
export default function RouterPreferenceToggle(): JSX.Element;
