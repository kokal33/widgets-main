/// <reference types="react" />
declare const _default: import("react").NamedExoticComponent<object>;
export default _default;
