export function validate(data: any, { instancePath, parentData, parentDataProperty, rootData }?: {
    instancePath?: string | undefined;
    parentData: any;
    parentDataProperty: any;
    rootData?: any;
}): boolean;
export default validate10;
declare function validate10(data: any, { instancePath, parentData, parentDataProperty, rootData }?: {
    instancePath?: string | undefined;
    parentData: any;
    parentDataProperty: any;
    rootData?: any;
}): boolean;
