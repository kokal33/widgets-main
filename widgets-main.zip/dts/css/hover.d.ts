export declare const iconHoverCss: import("styled-components").FlattenSimpleInterpolation;
