export declare const loadingOpacity = 0.6;
export declare const loadingCss: import("styled-components").FlattenSimpleInterpolation;
export declare const loadingTransitionCss: import("styled-components").FlattenInterpolation<import("styled-components").ThemedStyledProps<{
    isLoading: boolean;
}, import("styled-components").DefaultTheme>>;
