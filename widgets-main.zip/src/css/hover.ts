import { css } from 'styled-components/macro'

export const iconHoverCss = css`
  :hover {
    cursor: pointer;
    opacity: 0.6;
  }
`
